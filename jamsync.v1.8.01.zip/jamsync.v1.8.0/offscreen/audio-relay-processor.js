class AudioRelayProcessor extends AudioWorkletProcessor {
    constructor() {
        super();
        this.bufferSize = 4096;
        this.buffer = new Float32Array(this.bufferSize);
        this.ptr = 0;
    }
    process(inputs) {
        const input = inputs[0];
        if (input && input.length > 0 && input[0].length > 0) {
            const samples = input[0];
            for (let i = 0; i < samples.length; i++) {
                this.buffer[this.ptr++] = samples[i];
                if (this.ptr >= this.bufferSize) {
                    // Send copies of the buffer once filled
                    this.port.postMessage(this.buffer.slice());
                    this.ptr = 0;
                }
            }
        }
        return true;
    }
}
registerProcessor('audio-relay-processor', AudioRelayProcessor);
